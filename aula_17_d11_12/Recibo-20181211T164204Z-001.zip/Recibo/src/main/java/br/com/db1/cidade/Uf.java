package br.com.db1.cidade;

public enum Uf {
	PR,SC,SP
}
