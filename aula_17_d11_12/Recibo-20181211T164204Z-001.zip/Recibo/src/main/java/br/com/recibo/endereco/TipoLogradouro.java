package br.com.recibo.endereco;

public enum TipoLogradouro {
	RUA,AVENIDA,TRAVESSA,RODOVIA
}
