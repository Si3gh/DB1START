package br.com.db1.cidade.cidadeapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CidadeApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CidadeApiApplication.class, args);
	}
}
